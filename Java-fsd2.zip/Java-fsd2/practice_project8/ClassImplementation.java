package practice_project8;

public class ClassImplementation {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		System.out.println(" Class ClassImplemetation is class");
	}

}
