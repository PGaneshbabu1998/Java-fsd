package practice_project8;

public class Abstraction {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		CalcImp calimpl=new CalcImp();
		calimpl.sub(23,34);
	}

}
