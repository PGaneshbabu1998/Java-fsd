package com;

class Node2 {
    int data;
    Node2 next;
    Node2 prev;

    Node2(int data) {
        this.data = data;
        this.next = null;
        this.prev = null;
    }
}

class DoublyLinkedList {
    Node2 head;

    DoublyLinkedList() {
        this.head = null;
    }

    // Method to insert a new node at the end of the doubly linked list
    void insert(int data) {
        Node2 newNode = new Node2(data);

        if (head == null) {
            // If the list is empty, make the new node the head
            head = newNode;
        } else {
            Node2 temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
            newNode.prev = temp;
        }
    }

    // Method to traverse the doubly linked list in the forward direction
    void forwardTraversal() {
        System.out.println("Forward Traversal:");

        Node2 current = head;
        while (current != null) {
            System.out.print(current.data + " ");
            current = current.next;
        }

        System.out.println();
    }

    // Method to traverse the doubly linked list in the backward direction
    void backwardTraversal() {
        System.out.println("Backward Traversal:");

        Node2 last = getLastNode();
        while (last != null) {
            System.out.print(last.data + " ");
            last = last.prev;
        }

        System.out.println();
    }

    // Method to get the last node in the doubly linked list
    Node2 getLastNode() {
        Node2 last = head;
        while (last != null && last.next != null) {
            last = last.next;
        }
        return last;
    }
}

public class DoubleLinkedListTraversal {
    public static void main(String[] args) {
        DoublyLinkedList doublyList = new DoublyLinkedList();

        // Insert elements into the doubly linked list
        doublyList.insert(1);
        doublyList.insert(2);
        doublyList.insert(3);
        doublyList.insert(4);
        doublyList.insert(5);

        // Traverse the doubly linked list in both forward and backward directions
        doublyList.forwardTraversal();
        doublyList.backwardTraversal();
    }
}