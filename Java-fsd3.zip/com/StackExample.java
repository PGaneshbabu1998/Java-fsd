package com;

import java.util.Stack;

public class StackExample {

    public static void main(String[] args) {
        Stack<Integer> stack = new Stack<>();

        // Insert elements into the stack (push)
        pushElement(stack, 5);
        pushElement(stack, 10);
        pushElement(stack, 15);

        // Display the stack after insertions
        System.out.println("Stack after insertions:");
        printStack(stack);

        // Remove elements from the stack (pop)
        popElement(stack);

        // Display the stack after removal
        System.out.println("Stack after removal:");
        printStack(stack);
    }

    // Method to insert an element into the stack (push)
    static void pushElement(Stack<Integer> stack, int element) {
        System.out.println("Pushing element " + element + " onto the stack");
        stack.push(element);
    }

    // Method to remove an element from the stack (pop)
    static void popElement(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            System.out.println("Stack is empty. Cannot pop an element.");
        } else {
            int poppedElement = stack.pop();
            System.out.println("Popped element: " + poppedElement);
        }
    }

    // Method to print the elements of the stack
    static void printStack(Stack<Integer> stack) {
        if (stack.isEmpty()) {
            System.out.println("Stack is empty.");
        } else {
            System.out.println("Elements in the stack:");
            for (int element : stack) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
}
