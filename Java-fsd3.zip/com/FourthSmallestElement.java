package com;

import java.util.Arrays;

public class FourthSmallestElement {

    public static void main(String[] args) {
        int[] unsortedList = {10, 5, 8, 3, 2, 7, 1, 6, 4, 9};
        
        int fourthSmallest = findFourthSmallestElement(unsortedList);

        System.out.println("The fourth smallest element is: " + fourthSmallest);
    }

    static int findFourthSmallestElement(int[] arr) {
        if (arr.length < 4) {
            System.out.println("The array does not have enough elements.");
            return -1;
        }

        Arrays.sort(arr);

        return arr[3]; // Index 3 corresponds to the fourth smallest element in a zero-based array.
    }
}
