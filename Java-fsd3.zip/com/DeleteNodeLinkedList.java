package com;

class Node {
    int data;
    Node next;

    Node(int data) {
        this.data = data;
        this.next = null;
    }
}

class LinkedList {
    Node head;

    LinkedList() {
        this.head = null;
    }

    // Method to insert a new node at the end of the linked list
    void insert(int data) {
        Node newNode = new Node(data);
        if (head == null) {
            head = newNode;
        } else {
            Node temp = head;
            while (temp.next != null) {
                temp = temp.next;
            }
            temp.next = newNode;
        }
    }

    // Method to delete the first occurrence of a key in the linked list
    void delete(int key) {
        Node current = head;
        Node prev = null;

        // If the key is found at the head
        if (current != null && current.data == key) {
            head = current.next;
            return;
        }

        // Search for the key in the rest of the linked list
        while (current != null && current.data != key) {
            prev = current;
            current = current.next;
        }

        // If the key is not present
        if (current == null) {
            System.out.println("Key not found in the linked list.");
            return;
        }

        // Unlink the node with the key from the linked list
        prev.next = current.next;
    }

    // Method to print the linked list
    void printList() {
        Node temp = head;
        while (temp != null) {
            System.out.print(temp.data + " ");
            temp = temp.next;
        }
        System.out.println();
    }
}

public class DeleteNodeLinkedList {
    public static void main(String[] args) {
        LinkedList list = new LinkedList();

        list.insert(1);
        list.insert(2);
        list.insert(3);
        list.insert(4);
        list.insert(5);

        System.out.println("Original Linked List:");
        list.printList();

        int keyToDelete = 3;
        list.delete(keyToDelete);

        System.out.println("Linked List after deleting the first occurrence of " + keyToDelete + ":");
        list.printList();
    }
}
