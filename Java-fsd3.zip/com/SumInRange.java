package com;

import java.util.Scanner;

public class SumInRange {

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input the size of the array
        System.out.print("Enter the size of the array: ");
        int n = scanner.nextInt();

        // Input array elements
        int[] array = new int[n];
        System.out.println("Enter the array elements:");
        for (int i = 0; i < n; i++) {
            array[i] = scanner.nextInt();
        }

        // Input the range [L, R]
        System.out.print("Enter the value of L: ");
        int L = scanner.nextInt();
        System.out.print("Enter the value of R: ");
        int R = scanner.nextInt();

        // Calculate and print the sum in the specified range
        int sumInRange = calculateSumInRange(array, L, R);
        System.out.println("Sum of elements in the range [" + L + ", " + R + "]: " + sumInRange);

        scanner.close();
    }

    static int calculateSumInRange(int[] arr, int L, int R) {
        if (L < 0 || R >= arr.length || L > R) {
            System.out.println("Invalid range.");
            return -1;
        }

        int sum = 0;
        for (int i = L; i <= R; i++) {
            sum += arr[i];
        }
        return sum;
    }
}
