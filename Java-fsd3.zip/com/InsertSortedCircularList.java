package com;

class Node1 {
    int data;
    Node1 next;

    Node1(int data) {
        this.data = data;
        this.next = null;
    }
}

class CircularLinkedList {
    Node1 head;

    CircularLinkedList() {
        this.head = null;
    }

    // Method to insert a new element into a sorted circular linked list
    void insert(int data) {
        Node1 newNode = new Node1(data);

        if (head == null) {
            // If the list is empty, make the new node the head and point it to itself
            head = newNode;
            head.next = head;
        } else if (data <= head.data) {
            // If the new element is smaller than or equal to the head, insert it at the beginning
            Node1 last = getLastNode();
            newNode.next = head;
            head = newNode;
            last.next = newNode;
        } else {
            // Find the correct position to insert the new element in the sorted circular list
            Node1 current = head;
            while (current.next != head && current.next.data < data) {
                current = current.next;
            }

            newNode.next = current.next;
            current.next = newNode;
        }
    }

    // Method to get the last node in the circular linked list
    Node1 getLastNode() {
        Node1 last = head;
        while (last.next != head) {
            last = last.next;
        }
        return last;
    }

    // Method to print the circular linked list
    void printList() {
        if (head == null) {
            System.out.println("Circular Linked List is empty.");
            return;
        }

        Node1 current = head;
        do {
            System.out.print(current.data + " ");
            current = current.next;
        } while (current != head);

        System.out.println();
    }
}

public class InsertSortedCircularList {
    public static void main(String[] args) {
        CircularLinkedList circularList = new CircularLinkedList();

        // Insert elements into the sorted circular linked list
        circularList.insert(3);
        circularList.insert(7);
        circularList.insert(10);
        circularList.insert(15);
        circularList.insert(20);

        System.out.println("Original Circular Linked List:");
        circularList.printList();

        // Insert a new element into the sorted circular linked list
        int newElement = 12;
        circularList.insert(newElement);

        System.out.println("Circular Linked List after inserting " + newElement + ":");
        circularList.printList();
    }
}