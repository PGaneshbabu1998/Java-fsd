package com;

import java.util.LinkedList;
import java.util.Queue;

public class QueueExample {

    public static void main(String[] args) {
        Queue<Integer> queue = new LinkedList<>();

        // Insert elements into the queue (enqueue)
        enqueueElement(queue, 5);
        enqueueElement(queue, 10);
        enqueueElement(queue, 15);

        // Display the queue after insertions
        System.out.println("Queue after insertions:");
        printQueue(queue);

        // Remove elements from the queue (dequeue)
        dequeueElement(queue);

        // Display the queue after removal
        System.out.println("Queue after removal:");
        printQueue(queue);
    }

    // Method to insert an element into the queue (enqueue)
    static void enqueueElement(Queue<Integer> queue, int element) {
        System.out.println("Enqueuing element " + element + " into the queue");
        queue.add(element);
    }

    // Method to remove an element from the queue (dequeue)
    static void dequeueElement(Queue<Integer> queue) {
        if (queue.isEmpty()) {
            System.out.println("Queue is empty. Cannot dequeue an element.");
        } else {
            int dequeuedElement = queue.poll();
            System.out.println("Dequeued element: " + dequeuedElement);
        }
    }

    // Method to print the elements of the queue
    static void printQueue(Queue<Integer> queue) {
        if (queue.isEmpty()) {
            System.out.println("Queue is empty.");
        } else {
            System.out.println("Elements in the queue:");
            for (int element : queue) {
                System.out.print(element + " ");
            }
            System.out.println();
        }
    }
}
