package com;

public class ExponentialSearch {

    // Function to perform exponential search
    public static int exponentialSearch(int[] array, int target) {
        int n = array.length;

        // If the target is present at the first position
        if (array[0] == target) {
            return 0;
        }

        // Find the range for binary search by doubling the index
        int i = 1;
        while (i < n && array[i] <= target) {
            i *= 2;
        }

        // Perform binary search in the found range
        return binarySearch(array, target, i / 2, Math.min(i, n - 1));
    }

    // Function to perform binary search within a specified range
    private static int binarySearch(int[] array, int target, int low, int high) {
        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (array[mid] == target) {
                return mid; // Return the index if the target is found
            } else if (array[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return -1; // Return -1 if the target is not found
    }

    public static void main(String[] args) {
        // Example usage
        int[] sortedArray = {1, 2, 5, 6, 9, 12, 15};
        int target = 9;

        // Perform exponential search
        int result = exponentialSearch(sortedArray, target);

        // Display the result
        if (result != -1) {
            System.out.println("Target found at index: " + result);
        } else {
            System.out.println("Target not found in the array");
        }
    }
}