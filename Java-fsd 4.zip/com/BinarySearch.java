package com;

public class BinarySearch {

    // Function to perform binary search
    public static int binarySearch(int[] array, int target) {
        int low = 0;
        int high = array.length - 1;

        while (low <= high) {
            int mid = low + (high - low) / 2;

            if (array[mid] == target) {
                return mid; // Return the index if the target is found
            } else if (array[mid] < target) {
                low = mid + 1;
            } else {
                high = mid - 1;
            }
        }

        return -1; // Return -1 if the target is not found
    }

    public static void main(String[] args) {
        // Example usage
        int[] sortedArray = {1, 2, 5, 6, 9, 12, 15};
        int target = 9;

        // Perform binary search
        int result = binarySearch(sortedArray, target);

        // Display the result
        if (result != -1) {
            System.out.println("Target found at index: " + result);
        } else {
            System.out.println("Target not found in the array");
        }
    }
}
