package com;

public class InsertionSort {

    // Function to perform insertion sort
    public static void insertionSort(int[] array) {
        int n = array.length;

        for (int i = 1; i < n; i++) {
            int key = array[i];
            int j = i - 1;

            // Move elements greater than key to one position ahead
            while (j >= 0 && array[j] > key) {
                array[j + 1] = array[j];
                j--;
            }

            // Place the key at its correct position
            array[j + 1] = key;
        }
    }

    public static void main(String[] args) {
        // Example usage
        int[] array = {12, 11, 13, 5, 6};
        
        // Perform insertion sort
        insertionSort(array);

        // Display the sorted array
        System.out.println("Sorted array:");
        for (int i : array) {
            System.out.print(i + " ");
        }
    }
}
