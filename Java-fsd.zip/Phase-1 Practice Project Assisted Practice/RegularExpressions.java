package com;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegularExpressions {
	
	// Helper method to match and display pattern occurrences
    private static void matchPattern(String text, String pattern) {
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(text);

        while (m.find()) {
            System.out.println("Pattern '" + pattern + "' found at index " + m.start() + " - " + m.end());
        }
    }

    // Helper method to extract and display pattern occurrences
    private static void extractPattern(String text, String pattern) {
        Pattern p = Pattern.compile(pattern);
        Matcher m = p.matcher(text);

        while (m.find()) {
            System.out.println("Email Address: " + m.group());
        }
    }
    
	 public static void main(String[] args) {
	        // Example 1: Simple Pattern Matching
	        String text1 = "The quick brown fox jumps over the lazy dog.";
	        String pattern1 = "fox";

	        System.out.println("Example 1: Simple Pattern Matching");
	        matchPattern(text1, pattern1);

	        // Example 2: Pattern Matching with Quantifiers
	        String text2 = "aaaabbbbcccc";
	        String pattern2 = "a+b+c+";

	        System.out.println("\nExample 2: Pattern Matching with Quantifiers");
	        matchPattern(text2, pattern2);

	        // Example 3: Extracting Email Addresses
	        String text3 = "Contact us at support@example.com or info@test.com";
	        String emailPattern = "[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}";

	        System.out.println("\nExample 3: Extracting Email Addresses");
	        extractPattern(text3, emailPattern);
	    }

}
