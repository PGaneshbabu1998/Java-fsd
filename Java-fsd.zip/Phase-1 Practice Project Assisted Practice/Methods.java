package com;

public class Methods {
	
	// Method with no parameters and no return value
    void printHello() {
        System.out.println("Hello, World!");
    }

    // Method with parameters and no return value
    void printMessage(String message) {
        System.out.println("Message: " + message);
    }

    // Method with parameters and a return value
    int addNumbers(int a, int b) {
        return a + b;
    }
    
 // Method with no parameters and a return value
    int generateRandomNumber() {
        // Generating a random number between 1 and 100
        return (int) (Math.random() * 100) + 1;
    }

    // Static method with parameters and a return value
    static double calculateAverage(double x, double y) {
        return (x + y) / 2;
    }

    public static void main(String[] args) {
        // Creating an instance of the class to call non-static methods
        Methods example = new Methods();

        // Calling a method with no parameters and no return value
        example.printHello();

        // Calling a method with parameters and no return value
        example.printMessage("Java Methods");

        // Calling a method with parameters and a return value
        int sum = example.addNumbers(5, 7);
        System.out.println("Sum: " + sum);
        
        //Calling a method without parameters and a return value
        int random_value = example.generateRandomNumber();
        System.out.println("Random number : "+random_value);

        // Calling a static method using the class name
        double average = Methods.calculateAverage(10.5, 15.5);
        System.out.println("Average: " + average);

        // Calling a static method directly (if in the same class)
        double anotherAverage = calculateAverage(20.5, 25.5);
        System.out.println("Another Average: " + anotherAverage);
    }
}
