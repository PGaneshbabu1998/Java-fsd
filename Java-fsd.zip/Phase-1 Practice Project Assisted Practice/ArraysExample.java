package com;

public class ArraysExample {
	
	// Helper method to display the elements of an array
    private static void displayArray(int[] arr) {
        for (int element : arr) {
            System.out.print(element + " ");
        }
        System.out.println();
    }

    // Helper method to calculate the sum of elements in an array
    private static int calculateSum(int[] arr) {
        int sum = 0;
        for (int element : arr) {
            sum += element;
        }
        return sum;
    }
	
	public static void main(String[] args) {
        // Creating an array of integers
        int[] numbers = new int[5];

        // Initializing the array elements
        for (int i = 0; i < numbers.length; i++) {
            numbers[i] = i * 2;
        }

        // Displaying the elements of the array
        System.out.println("Array Elements:");
        displayArray(numbers);

        // Summing the elements of the array
        int sum = calculateSum(numbers);
        System.out.println("Sum of Array Elements: " + sum);

        // Modifying an element of the array
        numbers[2] = 100;

        // Displaying the modified array
        System.out.println("\nArray after Modification:");
        displayArray(numbers);
    }

}
