package com;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

public class Collections {
	
	public static void main(String[] args) {
        // ArrayList Example
        ArrayList<String> stringList = new ArrayList<>();

        // Adding elements to the ArrayList
        stringList.add("Java");
        stringList.add("Python");
        stringList.add("C++");

        // Displaying elements of the ArrayList
        System.out.println("ArrayList Example:");
        for (String language : stringList) {
            System.out.println(language);
        }
        System.out.println();

        // HashMap Example
        HashMap<String, Integer> ageMap = new HashMap<>();

        // Adding key-value pairs to the HashMap
        ageMap.put("Alice", 25);
        ageMap.put("Bob", 30);
        ageMap.put("Charlie", 28);

        // Displaying key-value pairs of the HashMap
        System.out.println("HashMap Example:");
        for (Map.Entry<String, Integer> entry : ageMap.entrySet()) {
            System.out.println("Name: " + entry.getKey() + ", Age: " + entry.getValue());
        }
    }
}
