package com;

//Class with default access modifier (no modifier)
class DefaultAccessClass {
	void display() {
		System.out.println("This is a default access class.");
	}
}

//Public class with a public method
public class AccessModifiers {
	
	// Public field
	 public int publicField = 10;

	 // Private field
	 private int privateField = 20;

	 // Protected field
	 protected int protectedField = 30;

	 // Default (package-private) field
	 int defaultField = 40;

	 // Public constructor
	 public AccessModifiers() {
	     System.out.println("Public constructor called.");
	 }

	 // Private method
	 private void privateMethod() {
	     System.out.println("Private method called.");
	 }

	 // Protected method
	 protected void protectedMethod() {
	     System.out.println("Protected method called.");
	 }

	 // Public method
	 public void publicMethod() {
	     System.out.println("Public method called.");
	 }

	 // Default (package-private) method
	 void defaultMethod() {
	     System.out.println("Default method called.");
	 }

	 public static void main(String[] args) {
		 
	     AccessModifiers example = new AccessModifiers();

	     // Accessing fields and methods from the same class
	     System.out.println("Public field: " + example.publicField);
	     System.out.println("Private field: " + example.privateField);
	     System.out.println("Protected field: " + example.protectedField);
	     System.out.println("Default field: " + example.defaultField);

	     example.publicMethod();
	     example.privateMethod();
	     example.protectedMethod();
	     example.defaultMethod();

	     // Accessing the default access class
	     DefaultAccessClass defaultAccessClass = new DefaultAccessClass();
	     defaultAccessClass.display();
	 }
	 
}

