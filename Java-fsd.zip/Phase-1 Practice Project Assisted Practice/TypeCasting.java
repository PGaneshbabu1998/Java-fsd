package com;

public class TypeCasting {
	
	public static void main(String[] args) {
        // Implicit casting (widening)
        int intValue = 10;
        double doubleValue = intValue; // Implicit casting from int to double
        System.out.println("Implicit Casting (Widening):");
        System.out.println("int value: " + intValue);
        System.out.println("double value: " + doubleValue);
        System.out.println();

        // Explicit casting (narrowing)
        double anotherDoubleValue = 20.5;
        int anotherIntValue = (int) anotherDoubleValue; // Explicit casting from double to int
        System.out.println("Explicit Casting (Narrowing):");
        System.out.println("double value: " + anotherDoubleValue);
        System.out.println("int value: " + anotherIntValue);
    }
	
}
