package com;

public class StringsConversation {
	
	public static void main(String[] args) {
        // Create a string
        String originalString = "Hello, Java!";

        // Display the original string
        System.out.println("Original String: " + originalString);

        // Convert string to StringBuffer
        StringBuffer stringBuffer = new StringBuffer(originalString);

        // Display the converted StringBuffer
        System.out.println("StringBuffer: " + stringBuffer);

        // Convert string to StringBuilder
        StringBuilder stringBuilder = new StringBuilder(originalString);

        // Display the converted StringBuilder
        System.out.println("StringBuilder: " + stringBuilder);
    }
}
