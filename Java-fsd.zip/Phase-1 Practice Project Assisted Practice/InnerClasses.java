package com;

public class InnerClasses {
	
    private String outerMessage = "Hello from OuterClass";

    // Member Inner Class
    class InnerClass {
        void displayInnerMessage() {
            System.out.println("Inner Message: " + outerMessage);
        }
    }

    public static void main(String[] args) {
        // Creating an instance of the outer class
    	InnerClasses outerObj = new InnerClasses();

        // Creating an instance of the inner class
    	InnerClasses.InnerClass innerObj = outerObj.new InnerClass();

        // Calling the method of the inner class
        innerObj.displayInnerMessage();
    }
}
