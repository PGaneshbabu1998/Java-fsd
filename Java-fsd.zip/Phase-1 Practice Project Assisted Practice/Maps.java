package com;

import java.util.HashMap;
import java.util.Map;

public class Maps {
	
	// Helper method to display the content of a map
    private static void displayMap(Map<String, Integer> map) {
        for (Map.Entry<String, Integer> entry : map.entrySet()) {
            System.out.println("Name: " + entry.getKey() + ", Age: " + entry.getValue());
        }
    }
	
	public static void main(String[] args) {
        // Creating a HashMap
        Map<String, Integer> ageMap = new HashMap<>();

        // Adding key-value pairs to the map
        ageMap.put("Alice", 25);
        ageMap.put("Bob", 30);
        ageMap.put("Charlie", 28);

        // Displaying the original map
        System.out.println("Original Map:");
        displayMap(ageMap);

        // Updating the value for the key "Alice"
        ageMap.put("Alice", 26);

        // Displaying the map after the update
        System.out.println("\nMap after updating 'Alice's age:");
        displayMap(ageMap);

        // Checking if the map contains a specific key
        String searchKey = "Bob";
        if (ageMap.containsKey(searchKey)) {
            System.out.println("\nThe map contains the key '" + searchKey + "' with age: " + ageMap.get(searchKey));
        } else {
            System.out.println("\nThe map does not contain the key '" + searchKey + "'.");
        }

        // Removing a key from the map
        String removeKey = "Charlie";
        ageMap.remove(removeKey);

        // Displaying the map after removing a key
        System.out.println("\nMap after removing '" + removeKey + "':");
        displayMap(ageMap);
    }

}
