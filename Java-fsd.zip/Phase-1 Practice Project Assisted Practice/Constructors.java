package com;

public class Constructors {
	
	// Field to store a message
    private String message;
    
 // Getter method for the message field
    public String getMessage() {
        return message;
    }

	// No-argument constructor
    public Constructors() {
        System.out.println("No-argument constructor called.");
    }

    // Parameterized constructor
    public Constructors(String message) {
        System.out.println("Parameterized constructor called with message: " + message);
    }

    // Copy constructor
    public Constructors(Constructors original) {
        System.out.println("Copy constructor called. Copying message from original.");
        if (original != null) {
            System.out.println("Original message: " + original.getMessage());
            this.message = original.getMessage();
        } else {
            System.out.println("Original is null. Setting default message.");
            this.message = "Default Message";
        }
    }

    public static void main(String[] args) {
        // Creating objects using different constructors
        Constructors obj1 = new Constructors();
        Constructors obj2 = new Constructors("Hello, Java Constructors!");
        
        // Creating an object using the copy constructor
        Constructors obj3 = new Constructors(obj2);

        // Displaying messages from the objects
        System.out.println("Message from obj1: " + obj1.getMessage());
        System.out.println("Message from obj2: " + obj2.getMessage());
        System.out.println("Message from obj3: " + obj3.getMessage());
    }
}
