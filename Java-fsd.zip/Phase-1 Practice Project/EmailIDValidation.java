package com;

import java.util.Scanner;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class EmailIDValidation {
	
	// Method to validate an email address using regular expressions
    private static boolean isValidEmail(String email) {
        // Regular expression for a basic email address pattern
        String emailPattern = "^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,}$";

        // Compile the pattern
        Pattern pattern = Pattern.compile(emailPattern);

        // Create a matcher with the given email
        Matcher matcher = pattern.matcher(email);

        // Return true if the email matches the pattern, otherwise false
        return matcher.matches();
    }
    
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Email Address Validation");

        // Input email address
        System.out.print("Enter an email address: ");
        String email = scanner.nextLine();

        // Validate the email address
        if (isValidEmail(email)) {
            System.out.println("Valid Email Address.");
        } else {
            System.out.println("Invalid Email Address.");
        }
        scanner.close();
    }

}
