package com;

import java.util.Scanner;

public class Calculator {
	
	public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        System.out.println("Simple Arithmetic Calculator");
        System.out.println("Enter two numbers:");

        // Input two numbers
        System.out.print("Number 1: ");
        double num1 = scanner.nextDouble();

        System.out.print("Number 2: ");
        double num2 = scanner.nextDouble();

        // Input arithmetic operator
        System.out.print("Enter an arithmetic operator (+, -, *, /, %): ");
        char operator = scanner.next().charAt(0);

        // Perform calculation based on the operator
        double result = 0.0;
        switch (operator) {
            case '+':
                result = num1 + num2;
                break;
            case '-':
                result = num1 - num2;
                break;
            case '*':
                result = num1 * num2;
                break;
            case '/':
                // Check for division by zero
                if (num2 != 0) {
                    result = num1 / num2;
                } else {
                    System.out.println("Error: Division by zero is not allowed.");
                    return; // Exit the program
                }
                break;
            case '%':
            	result = num1 % num2;
            	break;
            default:
                System.out.println("Error: Invalid operator");
                return; // Exit the program
        }

        // Display the result
        System.out.println("Result: " + result);
        scanner.close();
    }
}
